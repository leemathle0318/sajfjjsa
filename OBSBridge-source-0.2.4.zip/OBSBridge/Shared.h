#pragma once
#define OB_DOMAIN CFSTR("local.xiaoguai.obsbridge")
#define OB_NOTIFY "local.xiaoguai.obsbridge.changed"
#define OB_CONFIG @"/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.plist"
#define OB_STATUS @"/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.status.plist"
#define OB_PORT 5000
#define OB_VERSION @"0.2.4"
#define OB_ACCESS_PROFILE "local.xiaoguai.obsbridge.media-read"
#define OB_ACCESS_NOTIFY "local.xiaoguai.obsbridge.v4.media.read-permission"
#define OB_BUS_FILE "/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.media-v4.dat"
#define OB_BUS_NOTIFY "local.xiaoguai.obsbridge.v4.bus"
#define OB_MEDIA_HEARTBEAT "local.xiaoguai.obsbridge.v2.media.heartbeat"
#define OB_MEDIA_HOOKS "local.xiaoguai.obsbridge.v2.media.hooks"
#define OB_MEDIA_COUNTS "local.xiaoguai.obsbridge.v2.media.counts"
#define OB_MEDIA_MAPPING "local.xiaoguai.obsbridge.v4.media.mapping"
#define OB_SHORTCUT_STATUS @"/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.shortcut.status.plist"
