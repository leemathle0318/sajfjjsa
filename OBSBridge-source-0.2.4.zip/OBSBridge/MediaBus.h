#pragma once
#import <Foundation/Foundation.h>
#import <CoreVideo/CoreVideo.h>
#include "core/SharedMedia.hpp"
#include "core/MappedMedia.hpp"
#include <sys/mman.h>
#include <memory>

// Producer methods are only used in SpringBoard. The mapped file persists
// for that process's lifetime, including while receiving is stopped.
NSString *OBBusCreate(void);
void OBBusEnable(BOOL enabled);
void OBBusHeartbeat(void);
void OBBusResetAudio(void);
void OBBusWriteAudio(const float *samples, size_t count, double due);
BOOL OBBusPublishVideo(CVPixelBufferRef source, double due);
NSString *OBBusProducerStatus(void);
uint64_t OBBusSession(void);
// Consumer mappings report lookup failures rather than silently failing.
struct OBMapping {
    const obs::MappedMedia *memory;
    const obs::SharedMedia *data;
    explicit OBMapping(obs::MappedMedia *m) : memory(m), data(&m->state) {}
    ~OBMapping() { munmap(const_cast<obs::MappedMedia *>(memory), sizeof(obs::MappedMedia)); }
};
struct OBVideoLease {
    std::shared_ptr<OBMapping> mapping;
    CVPixelBufferRef pixel;
    OBVideoLease(std::shared_ptr<OBMapping> m, CVPixelBufferRef p) : mapping(m), pixel(p) {}
    ~OBVideoLease() { CVPixelBufferRelease(pixel); } // owns a private snapshot; no shared lease writes
};
std::shared_ptr<OBMapping> OBBusConsumer(void);
NSString *OBBusConsumerError(void);
// A private pixel snapshot is returned; readers never write the mapped file.
std::unique_ptr<OBVideoLease> OBBusCopyVideo(void);
void OBMediaHeartbeat(uint32_t hookCount, uint64_t videoCalls, uint64_t audioCalls,
                      uint64_t replaced, uint64_t mixed, uint32_t failure);
NSString *OBMediaStatus(void);
FOUNDATION_EXPORT double OBNow(void);
