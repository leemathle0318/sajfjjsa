#pragma once
#include "SharedMedia.hpp"
namespace obs {
constexpr uint32_t FileMagic = 0x4f424634, FileVersion = 4;
constexpr size_t MaximumPixels = 1280 * 720, MaximumFrameBytes = MaximumPixels * 4;
struct FrameGeometry {
    uint32_t width, height, stride;
    bool valid() const {
        return width && height && width <= 1280 && height <= 1280 && stride == width * 4 &&
            uint64_t(width) * height <= MaximumPixels;
    }
};
// Writer invalidates the slot sequence before changing any payload. Readers
// only load atomic words and verify the sequence again after copying. They
// never modify leases or any mapped memory (PROT_READ is sufficient).
struct RawVideo {
    std::atomic<uint32_t> width{0}, height{0}, stride{0};
    std::array<std::atomic<uint32_t>, MaximumPixels> pixels;
    FrameGeometry geometry() const {
        return {width.load(std::memory_order_relaxed), height.load(std::memory_order_relaxed), stride.load(std::memory_order_relaxed)};
    }
    bool valid() const { return geometry().valid(); }
    bool write(const uint8_t *source, size_t row, uint32_t w, uint32_t h) {
        if (!source || !w || !h || w > 1280 || h > 1280 || uint64_t(w) * h > MaximumPixels ||
            row < size_t(w)*4 || row > SIZE_MAX / h)
            return false;
        width.store(w, std::memory_order_relaxed); height.store(h, std::memory_order_relaxed);
        stride.store(w*4, std::memory_order_relaxed);
        for (uint32_t y = 0; y < h; ++y) for (uint32_t x = 0; x < w; ++x) {
            uint32_t word; std::memcpy(&word, source+size_t(y)*row+size_t(x)*4, 4);
            pixels[size_t(y)*w+x].store(word, std::memory_order_relaxed);
        }
        return true;
    }
    void clear() {
        width.store(0, std::memory_order_relaxed); height.store(0, std::memory_order_relaxed); stride.store(0, std::memory_order_relaxed);
        for (auto &pixel : pixels) pixel.store(0, std::memory_order_relaxed);
    }
    bool copy(FrameGeometry g, uint8_t *destination, size_t row, size_t capacity) const {
        if (!g.valid() || !destination || row < g.stride || row > SIZE_MAX / g.height || capacity < row * g.height)
            return false;
        for (uint32_t y = 0; y < g.height; ++y) for (uint32_t x = 0; x < g.width; ++x) {
            uint32_t word = pixels[size_t(y)*g.width+x].load(std::memory_order_relaxed);
            std::memcpy(destination+size_t(y)*row+size_t(x)*4, &word, 4);
        }
        return true;
    }
};
struct alignas(64) MappedMedia {
    std::atomic<uint32_t> magic{0};
    uint32_t version = FileVersion;
    uint64_t bytes = sizeof(MappedMedia), cookie = 0;
    SharedMedia state;
    std::array<RawVideo, 3> frames;
    void initialize(uint64_t session) {
        cookie = session; state.initialize(); magic.store(FileMagic, std::memory_order_release);
    }
    bool valid(uint64_t session) const {
        return magic.load(std::memory_order_acquire) == FileMagic && version == FileVersion &&
            bytes == sizeof(MappedMedia) && cookie == session && session != 0;
    }
};
struct FrameTicket {
    unsigned slot;
    uint32_t sequence, generation;
    uint64_t due;
    FrameGeometry geometry;
};
inline void beginFrameWrite(VideoSlot &slot) {
    slot.sequence.store(0, std::memory_order_relaxed);
    // A reader that observes any of the following atomic payload stores must
    // also observe this invalidation before its final sequence check.
    std::atomic_thread_fence(std::memory_order_release);
}
inline bool captureFrame(const MappedMedia &bus, unsigned index, uint64_t now, FrameTicket &ticket) {
    if (index >= 3 || !bus.state.fresh(now)) return false;
    const auto &slot = bus.state.video[index];
    uint32_t sequence = slot.sequence.load(std::memory_order_acquire);
    if (!sequence || slot.lease.load(std::memory_order_acquire) == WriterLease) return false;
    uint32_t generation = bus.state.generation.load(std::memory_order_acquire);
    uint64_t due = slot.dueUS.load(std::memory_order_relaxed);
    FrameGeometry geometry = bus.frames[index].geometry();
    if (!geometry.valid() || slot.surface.load(std::memory_order_relaxed) != index+1 ||
        slot.generation.load(std::memory_order_relaxed) != generation || due > now || now-due >= 500000)
        return false;
    ticket = {index, sequence, generation, due, geometry};
    return true;
}
inline bool frameUnchanged(const MappedMedia &bus, const FrameTicket &ticket, uint64_t now) {
    if (ticket.slot >= 3) return false;
    // Order all payload reads before the second sequence check.
    std::atomic_thread_fence(std::memory_order_acq_rel);
    const auto &slot = bus.state.video[ticket.slot];
    return slot.sequence.load(std::memory_order_acquire) == ticket.sequence && ticket.sequence &&
        slot.lease.load(std::memory_order_acquire) != WriterLease &&
        slot.generation.load(std::memory_order_acquire) == ticket.generation &&
        bus.state.generation.load(std::memory_order_acquire) == ticket.generation && bus.state.fresh(now);
}
inline bool copyFrame(const MappedMedia &bus, const FrameTicket &ticket, uint64_t now,
                      uint8_t *destination, size_t row, size_t capacity) {
    if (!frameUnchanged(bus, ticket, now) ||
        !bus.frames[ticket.slot].copy(ticket.geometry, destination, row, capacity)) return false;
    return frameUnchanged(bus, ticket, now);
}
}
