#pragma once
#include <cmath>
#include <limits>

namespace obs {
// Main-thread-only observer: never consumes the system's normal volume action.
class UpDownShortcut {
public:
    static constexpr double Window = .8;
    static constexpr double Cooldown = 2.;
    bool button(bool up, double now, bool allowed = true) {
        if (!allowed || !std::isfinite(now)) { reset(); return false; }
        if (now < lastEvent_) { reset(); lastTrigger_ = -INFINITY; }
        lastEvent_ = now;
        if (now - lastTrigger_ < Cooldown) { armed_ = false; return false; }
        if (now < blockedUntil_) {
            if (up) blockedUntil_ = now + Window;
            return false;
        }
        if (up) {
            if (armed_ && now - upAt_ <= Window) {
                // A repeated/held Up must not continuously extend the sequence.
                armed_ = false; blockedUntil_ = now + Window;
            } else { armed_ = true; upAt_ = now; }
            return false;
        }
        double gap = now - upAt_;
        bool trigger = armed_ && gap >= .04 && gap <= Window;
        armed_ = false;
        if (trigger) lastTrigger_ = now;
        return trigger;
    }
    void reset() { armed_ = false; blockedUntil_ = -INFINITY; }
private:
    bool armed_ = false;
    double upAt_ = 0, lastEvent_ = -INFINITY;
    double blockedUntil_ = -INFINITY, lastTrigger_ = -INFINITY;
};
}
