#pragma once
#import <Foundation/Foundation.h>
// Request only our media-cache read permission, asynchronously. Never called
// synchronously from camera/audio callbacks; libSandy is an external dependency.
void OBRequestMediaReadAccess(void);
NSString *OBMediaReadAccessStatus(void);
